#Try to write a code for printing sequence of numbers from 1 to 50 with the differences of 3, 5, 10 
seq(1:50)
seq(1, 50, by = 3)
seq(1,50, by = 5)
seq(1,50, by = 10)


#What are the different data objects in R? and write syntax and example for each and every object
#Data Objects
# 1) Vectors
# 2) Lists
# 3) Matrices
# 4) Array
# 5) Factors
# 6) Dataframe
#Vector Data object
#Vector of type character
print("Arya")
#Vector of type double
print(12.5)
#Vector of type integer
print(20)
#Vector of type logical
print(TRUE)
#Vector of type complex
print(2+5i)
#Vector of type raw
print(charToRaw('Hi'))
#printing sequence from 1 to 10 
v <- 1:10
print(v)
#Vector Addition
v1 <- c(5,7,8)
v2 <- c(1,2,3)

add.result <- v1+v2
print(add.result)

#Accessing vector elements using position
t <- c("Jan","Feb","Mar","April","May","June","July","Aug","Sep","Oct","Nov","Dec")
u <-t[c(4,5,6,7,8,10)]
print(u)

#Sorting the element of Vector
v <- c(3,8,-1,0,1,9,7,2)
sort.result <- sort(v)
print(sort.result)


#Creating a list vector
#List vector contaning strings, numbers, vectors and logical
list_data <- list("Black","Yellow", c(22,55,66), TRUE, 22.33, 4.6)
print(list_data)

#List contaning vector, a matrix and  a list
list_data <- list(c("Jan","Feb","Mar"), matrix(c(2,4,6,8,9,-2), nrow = 2), list("Black", 5.5))
#Name to the element in the list
names(list_data) <- c("First Quarter", "A_Matrix", "A Inner list")
#Show the list
print(list_data)

#Converting list to vector
list1 <- list(1:5)
print(list1)

list2 <-list(6:10)
print(list2)

v1 <- unlist(list1)
v2 <- unlist(list2)

print(v1)
print(v2)

result <- v1+v2
print(result)


#MATRICES
#Syntax
#matrix(data, nrow, ncol, byrow, dimnames)
#Elements arranged sequentially by row
M <- matrix(c(3:14), nrow=4, byrow=TRUE)
print(M)

#Elements arranged sequentially by column
N <- matrix(c(3:14), nrow=4, byrow=FALSE)
print(N)

rownames =c("row1", "row2", "row3", "row4")
colnames= c("col1", "col2", "col3")

P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))
print(P)

#Accessing elements from matrix
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))

print(P[1,2])

print(P[3,2])

print(P[1,])

print(P[,2])

#Matrix computations
matrix1 <- matrix(c(4, 8, -2, 5, 3, 7), nrow = 3)
print(matrix1)

matrix2 <- matrix(c(5, 3, 1, 4, 4, 8), nrow = 3)
print(matrix2)

result <- matrix1 * matrix2
print(result)


#Array
vector1 <- c(4,8,2)
vector2 <- c(1,2,3,4,5,6)

result <- array(c(vector1, vector2),dim = c(3,3,2))
print(result)

#Accessing array elements
vector1 <- c(4,8,2)
vector2 <- c(1,2,3,4,5,6)
column.names <- c("col1", "col2", "col3" )
row.names <- c("row1", "row2", "row3")
matrix.names <- c("Mat1","Mat2")

result <- array(c(vector1,vector2),dim = c(3,3,2),dimnames = list(row.names, column.names, matrix.names))
print(result[1,,2])

print(result[2,3,2])

print(result[,,2])

#calculation across array elements
#syntax
#apply(x, margin, fun)
vector1 <- c(4,8,2)
vector2 <- c(1,2,3,4,5,6)
new.array <- array(c(vector1,vector2),dim = c(3,3,2))
print(new.array)
result <- apply(new.array, c(1), sum)
print(result)


#FACTOR
data <- c("A", "B", "C", "C", "A", "B", "B", "B", "A", "C")
print(data)
print(is.factor(data))
factor_data <- factor(data)
print(factor_data)
print(is.factor(factor_data))

#Data Frame
e.data <- data.frame(e_id = c(1:3), e_name = c("Tom", "Ram", "Jack"), designation = c("CEO", "Manager", "Employee"),
                       working_days = c(2, 4, 6), stringsAsFactors =FALSE)
print(e.data)



#3)Create Data frame with 3 columns and 5 rows and write a code to fetch and delete row and a column using index and add new column and row to the existed data frame
stud.data <- data.frame(stud_id = c(1:5), stud_name = c("Nisha", "Usha", "Asha", "John", "Tom"), stud_course = c("Advance Excel", "Tableau", "Python", "R Programming", "Power BI"), stringsAsFactors = FALSE)
result <- stud.data[1:5,]
print(result)

#Deleting row and column using index
stud.data1 = stud.data[-c(2),]
print(stud.data1)
stud.data1 = stud.data[-2]
print(stud.data1)

#Adding new column and row to the existed data frame
stud.data <- data.frame(stud_id = c(1:5), stud_name = c("Nisha", "Usha", "Asha", "John", "Tom"), stud_course = c("Advance Excel", "Tableau", "Python", "R Programming", "Power BI"), stringsAsFactors = FALSE)

stud.newdata <- data.frame(stud_id= c(6:9), stud_name = c("Kanchan", "Kiran", "Sham", "Deep"), stud_course = c("C", "C++", "Java", "MYSQL"), stringsAsFactors = FALSE)

stud.finaldata <- rbind(stud.data,stud.newdata)
print(stud.finaldata)



#4)Write nested if else statements to print whether the given number is negative, positive or Zero 
number = 22
if(number > 0) {
  print("Number is positive")
} else {
  if(number == 0) {
    print("Number is zero")
  } else {
    print("Number is negative")
  }
}
  


#5)Write a program to input any value and check whether it is character, numeric or special character
ch = "2"
print("Enter the value: ")
if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
  print("This is an alphabet")
} else {
  if(ch >= '0' && ch <= '9') {
  print("This is number")
} else {
  print("This is a special character")
}
}


#6)write difference between break and next also write examples for both 
#Break keyword is a jump statement that is used to terminate the loop at a particular iteration
#Syntax: if(test_expression){break}
#Next statement is used to skip the current itertion in the loop and move to the next iteration without exiting from the loop itself.
#Syntax: if(test_condition){next}
#Example
#Break
v <- c("Hello","Have a nice day")
cnt <- 2
repeat {
  print(v)
  cnt <- cnt+1
  if(cnt > 5)
  {
    break
  }
}

#Next
v <- LETTERS[1:6]
for(i in v){
  if(i == "A"){
    next
  }
    print(i)
}


#7)Write a program to print a given vector in reverse format  
#x= c(1,5.6,3,10,3.5,5)
x= c(1,5.6,3,10,3.5,5)
rev.default(x)
rev(x)


#8)write a program to get the mode value of the given vector ('a','b','c','t','a','c','r','a','c','t','z','r','v','t','u','e','t')
getmode <- function(v) {
  uni <- unique(v)
  uni[which.max(tabulate(match(v, uni)))]
}
v <- c("a","b","c","t","a","c","r","a","c","t","z","r","v","t","u","e","t")
result <- getmode(v)
print(result)


#9)Write a function to filter only data belongs to 'setosa' in species of Iris dataset.( using dplyr package) 
library(dplyr)
filter(iris, Species=="setosa")


#10)Create a new column for iris dataset with the name of Means_of_obs, which contains mean value of each row.( using dplyr package)
library(dplyr)
iris_subset$means_of_obs <- apply(iris_subset, 1, mean)
head(iris_subset)


#11)Filter data for the "versicolor" and get only 'sepel_length' and Sepel _width' columns.( using dplyr package)
library(dplyr)
filter(iris, Species=="versicolor")
select(iris, Sepal.Length:Sepal.Width)


#12)Create below plots for the mtcars also write your inferences for each and every plot (use ggplot package) Use Different ( Size , Colour )
#SCATTER PLOT
library(ggplot2)
ggplot(mtcars, aes(x = drat, y = mpg)) +
  geom_point(aes(color = factor(gear)))


ggplot(mtcars, aes(x = log(mpg), y = log(drat))) +
  geom_point(aes(color = factor(gear)))

my_graph <- ggplot(mtcars, aes(x = log(mpg), y = log(drat))) +
  geom_point(aes(color = factor(gear))) +
  
  stat_smooth(method = "lm", col = "#C42126", se = FALSE, size =1)
my_graph

my_graph + labs(title = "Plot Mile per hours and drat, in log")

mean_mpg <- mean(mtcars$mpg)
my_graph + labs(title = paste0("Plot Mile per hours and drat, in log. Average mpg is: ", mean_mpg))

my_graph + 
  labs(title = "Relation between Mile per hours and drat", 
       subtitle = "Relationship break down by gear class", 
       caption = "Authors own computation")

my_graph +
  theme_classic() +
  labs(
    x= "Drat definition, in log",
    y="Mile per hours, in log",
    color ="Gear",
    title = "Relation between Mile per hours and drat", 
    subtitle = "Relationship break down by gear class", 
    caption = "Authors own computation")
ggsave("my_scatter_plot.png")  


#BOX PLOT
boxplot(mpg ~ cyl, data = mtcars, xlab = "Number of cylinders",
        ylab = "Miles Per Gallon", main = "Mileage Data")
dev.off()

boxplot(mpg ~ cyl, data = mtcars, 
        xlab = "Number of cylinders",
        ylab = "Miles Per Gallon",
        main = "Mileage Data",
        notch = TRUE,
        varwidth = TRUE,
        col = c("grey", "yellow", "pink"),
        names = c("Low", "Medium", "High"))
dev.off()

#HISTOGRAM
ggplot(data  = mtcars, aes( x = mpg)) + geom_histogram( ) 
  

#LINE GRAPH
ggplot(data=mtcars, aes(x=cyl, y=disp, group=1)) +
geom_line()+
  geom_point()

  
#BAR GRAPH
head(mtcars)
str(mtcars)
counts <- table(mtcars$gear)
print(counts)
barplots(counts, main="Car Distribution", xlab="Number of gears")
barplot(counts, xlab="Gears",
        main="Car distribution by Gear and Cylinder",
        col = c("purple", "Grey", "Yellow"),
        beside=TRUE,
        names.arg= c("3 Gears", "4 Gears", "5 Gears"))
legend("topright", c("4 cylinder", "6 cylinder", "8 cylinder"), fill=c("purple", "Grey", "Yellow"))

